package assignment.pkg4;

import java.util.Scanner;

/**
 * This is the main class in the Assignment 4 project.
 * @author Christian Brito
 */
public class NimTester
{
    
    /**
     * Main method where we create a Nim object and play the game till the user no longer desires to play.
     * @param args 
     */
    public static void main(String[] args)
    {
        
        Scanner scnr = new Scanner(System.in);
        boolean cont = true;   // boolean holding status to continue or not.

        
        
        do // Run game while player wants to continue
        {     
           Nim game = new Nim();  // Nim game
           game.play();// Start game    
           int answer;  // Int to represent answer for player if they would like to continue.
      
            do // Ask to play again until valid input is entered
            {
                System.out.println("\n1Would you like to play again?");    // Ask Player if they would like to play again
                System.out.println("Enter *[1] for Yes or*[2] for No");
                answer = scnr.nextInt();   // get user input
                
                if(!(answer == 1) && !(answer == 2))    // If input invalid
                {
                    System.out.println("Invalid input plese try again");    // Display error message
                    answer = scnr.nextInt(); 
                }

           }while( !(answer == 1) && !(answer == 2) ); // Ask till input is valid
 
            
            // User wants to end game then set cont to false and terminate process
            if(answer == 2)  // If 2
            {
                cont = false; // then don't continue
            }           
        }while(cont);    
        
        

        
    }
    
}
