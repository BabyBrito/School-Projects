/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg4;

import java.util.Random;

/**
 * This Class creates a SmartComputer() object that plays the Nim game and implements the Player Interface.
 * This type of Player plays the game by checking if its a winnable situation and determines that if it is,
 * then remove the amount to win the game, or if it's not in a winnable situation remove a random amount 
 * from 1 to (n - 1) / 2.
 * @author Brito
 */
public class SmartComputer implements Player
{
    private String name;    // Name of Player
    private int[] pileSizeToMake;   // Integer array to hold the sizes desired for a pile to be made
    
    /**
     * Constructor for the SmartComputer() object where we pass through the name
     * and assign it to givenName passed through the parameter.
     * We also create a int[] representing the both the goal and the possible losing
     * situations for the game.
     * @param givenName 
     */
    public SmartComputer(String givenName)
    {
        name = givenName;     // Passes through its given name when created in the play()
        pileSizeToMake = new int[] {1, 3, 7, 15, 31, 63};   // Desired Pile sizes & size where a loosing situation occurs.
    }
        
    
    /**
     * This method returns the SmartComputer() object's name.
     * @return name
     */
    public String getName()
    {
        return name;      // To retrieve name in the play() & Winner Statement
    }
    
    /**
     * This method does 
     */
    public void move(Pile pile)
    {
        
        //Section 1: See if the situation is Winnable.
        boolean winnable = true;  // Boolean variable to hold answer if the situatuion is winnable. Situation is winnable
                                  // if the pile size does not equal any of the values from the pileSizeToMake array

        for(int j = 0; j < pileSizeToMake.length; j++)  // Checks to see if the pile size equals any of the values
        {
            if(pile.getSize() == pileSizeToMake[j])  // If so and Huamn could possible beat us then,
            {   
                winnable = false; // winnable equals false
            }
        }
        

        // Section 2: Set ammount to take and store it in the amountToTake integer variable.
        int marblesToTake = 0;   // Place holder for the amount to be removed
        if(winnable) // If situatuion is currently winnable
        {
            for(int i =  pileSizeToMake.length - 1; i > -1; i--)  // Checks through each of the sizes and sets or resets the amount to the new valid amount
            {
                if(pileSizeToMake[i] <  pile.getSize())     // if the size that can be made is less then the size of the pile
                {
                    marblesToTake = (pile.getSize() - pileSizeToMake[i]);    // the amountToTake will equal  the size minus the desired size for example
                    break;                                                  // pile size = 84 , size to Make = 63, them amountToTake = 84 - 63 which equals 21.
                }                   
            }
        }
        else // If situation is currently not winnable
        {
            Random rand = new Random();
            int limit = 0;   // Limit to how much can be taken
        
            if(pile.getSize() > 1)  // If thier is more then 1 marble
            {
                if(!(pile.getSize() % 2 == 0) &&  pile.getSize() > 1)   // If pile size is odd then,
                {
                    limit = (pile.getSize() -1) / 2;   // limit equals the plie size minus 1 and divided by 2.  ( (n - 1) / 2 )
                }
                 else  // If pile size even then,
                {
                    limit = pile.getSize() / 2;  // limit equals the pile size divided by 2  ( n / 2 )
                }
            }
            
            if(pile.getSize() > 1) // If greater then 1
            {
                marblesToTake = rand.nextInt(limit) + 1;  // Int to represent the amout to take set  to a random num from 1 to the limit
            }
            else // If not
            {
                marblesToTake = 1;  // takw 1
            }   
            
        }
        
        
        //Section 3: Call takeMarbles() and remove amount set by marblesToTake
        pile.takeMarbles(marblesToTake); 
   
    }

  
}
