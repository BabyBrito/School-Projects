package assignment.pkg4;

import java.util.Scanner;

/**
 * This Class creates a Human object that plays the Nim game and implements the Player Interface
 * This type of Player interacts with the game via command inputs based on the information
 * being displayed on the screen.
 * @author Brito
 */
public class Human implements Player
{
    
    private String name;
    
    /**
     * Constructor of Human() and initializes name to the givenName
     * that's pass through the parameter.
     * @param givenName 
     */
    public Human(String givenName)
    {
        name = givenName;
    }
    
   
    /**
     * This method does 3 things;
     * First, it finds the limit to the amount that can be taken from the pile.
     * Second, it asks the Human Player how much they would like to take until a valid amount is entered.
     * Third,  it calls the Pile.takeMarbles() method to remove amount from the pile.
     * @param pile 
     */
    @Override
    public void move(Pile pile)
    {
        
        // Section 1: Set a limit.
        int limit;  // limit on how many marbles can be taken.

        if(pile.getSize() > 1)  // If thier is more then 1 marble
        {
            if(!(pile.getSize() % 2 == 0) &&  pile.getSize() > 1)   // If pile size is odd then,
            {
                limit = (pile.getSize() -1) / 2;   // limit equals the plie size minus 1 and divided by 2.
            }
            else  // If pile size even then,
            {
                limit = pile.getSize() / 2;  // limit equals the pile size divided by 2
            }
        }
        else   // If their is only a single marblie in the pile
        {
            limit = 1;   // limit is 1
        }
           
        
        
        // Section 2: Ask Player for amount to take until a valid amount is entered.
        Scanner scnr = new Scanner(System.in);
        System.out.println(name + " how many marbles would you like to take from 1 to " + limit + "\n");
        int amountToTake; // Amount to take that will be set to the user's input/
        
        do{  
        System.out.print("Enter Amount: ");
        amountToTake = scnr.nextInt(); // Amount entered
        
        if(amountToTake > limit || amountToTake < 1) // Display Error Message if answer is invalid
        {
            System.out.println("Sorry this amount is invalid please select a number between 1 and " + limit + "\n");
        }  
        
        }while(amountToTake > limit || amountToTake < 1); // Continue loop until valid amount is entered
       
        
        
        // Section 3: Take amount entered.
        pile.takeMarbles(amountToTake); // Take valid Marbles
        
    }

     
    /**
     * This method returns the Humans name
     * @return name
     */
    @Override
    public String getName()
    {
        return name;  // Return name
    }
        
    
}
