package assignment.pkg4;

import java.util.Random;

/**
 * This Class creates a pile() object used to represent a pile of marbles for the
 * Nim game.
 * @author Brito
 */
public class Pile {
    
    private int marbles;        // Integer representing marbles in the pile;
    private int marblesTaken;   // Integer to hold value for printing in the play()
    
    /**
     * Constructor for the pile() object where we set marbles to a random int from 
     * 20 - 95, and we initialize marblesTake to 0.
     */
    public Pile()
    {   
        Random rand = new Random();
        marbles = rand.nextInt(76) + 20;  // nextInt( from 0 - 75) + 20; = 20 to 95
        marblesTaken = 0;                 // 0 for initialization.
    }
    
   
    /**
     * This method takes an amount of marbles from the object by subtracting the marbles variable
     * with num that is pass through the method in the parameter.
     * @param num 
     */
    public void takeMarbles(int num) 
    {
        marblesTaken = num;            // Pass the value to be taken  & Place holdeer for print statement
        marbles -= marblesTaken;       // Remove marbles taken from pile
    }
   
    
    /**
     * This method returns the variable marbles which is the amount of marbles in the pile.
     * @return marbles
     */
    public int getSize()   
    {
        return marbles;
    }
    
    
    /**
     * This method returns the marblesTaken variable which is the last amount taken from the pile.
     * @return marblesTaken
     */
    public int getMarblesTaken()
    {
        return marblesTaken;
    }
}
