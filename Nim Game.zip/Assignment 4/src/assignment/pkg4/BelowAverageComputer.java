package assignment.pkg4;

import java.util.Random;

/**
 * This Class creates a BelowAverageComputer() object that implements the Player Interface.
 * This type of Player plays the game by removing a random amount of marbles from 1 to the 
 * highest amount allowed.
 * @author Brito
 */
public class BelowAverageComputer implements Player
{
    
    
    private String name;    // Name of Player
    
    
    /**
     * Constructor for the BelowAverageComputer() object where we initialize the name to
     * the givenName passed through the parameter.
     * @param givenName 
     */
    public BelowAverageComputer(String givenName)
    {
        name = givenName;    // Passes through its given name when created in the play()
    }
        
    
    /**
     * This method returns the BelowAverageCompuer's name.
     * @return name
     */
    @Override
    public String getName()
    {
        return name;    // To retrieve name in the play() & Winner Statement
    }
    
    
    /**
     * This method does three things;
     * First, it sets a limit from 1 to (n - 1) / 2.
     * Second, creates a variable to hold the amount to be taken from a random int from 1 to the limit.
     * Third, removes amount set from the pile.
     * @param pile 
     */
    @Override
    public void move(Pile pile)
    {
        
        // Section 1: Set a limit
        Random rand = new Random(); 
        int limit = 0;   // Limit to how much can be taken
        
        if(pile.getSize() > 1)  // If thier is more then 1 marble
        {
            if(!(pile.getSize() % 2 == 0) &&  pile.getSize() > 1)   // If pile size is odd then,
            {
                limit = (pile.getSize() -1) / 2;   // limit equals the plie size minus 1 and divided by 2.  ( (n - 1) / 2 )
            }
            else  // If pile size even then,
            {
                limit = pile.getSize() / 2;  // limit equals the pile size divided by 2  ( n / 2 )
            }
        }
        
        
        // Section 2: Set amount to be taken
        int marblesToTake;  // Temp value
        
        if(pile.getSize() > 1) // If greater th2en 1
        {
            marblesToTake = rand.nextInt(limit) + 1;  // int to represent the amout to take set  to a random num from 1 to the limit
        }
        else // If not
        {
            marblesToTake = 1; // Take 1
       }
        
                
        // Section 3: Call takeMarbles() and remove amount set by marblesToTake
        pile.takeMarbles(marblesToTake);    // Remove amount set to be taken from pile
    }

    
}
