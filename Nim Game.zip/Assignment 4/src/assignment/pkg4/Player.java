package assignment.pkg4;

    /**
     * This interface is implemented by objects that have both a move() method and a getName() method. This class
     * is called in the Nim name to represent a player in the game;
     * @author Brito
     */
    public interface Player 
    {
        /**
         * This method initiates a move for a player to make.
         * @param pile 
         */
        public void move(Pile pile);
        
        /**
         * This method returns the Player's name.
         * @return name
         */
        public String getName();   
    }
