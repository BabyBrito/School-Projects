/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg4;

import java.util.Scanner;

/**
 * This Class creates a Nim() object where we create 2 Players, a pile, and create a multi-line
 * String representation of either an announcement of a winner or the results of a single turn.
 * @author Brito
 */
public class Nim {
    
    private Player player1;     // First Player
    private Player player2;     // Second Player
    private Pile pile;          // Pile of marbles    
    private String winner;      // Winner annoucment
    private String turnOutput;  // Turn information
    public Scanner scnr = new Scanner(System.in);
    
    /**
     * Constructor for the Nim() object where we initialize the Players through the generatePlayer()
     * method, and we initialize the pile, and both Strings.
     */
    public Nim()
    {
        player1 = generatePlayer(1);     // User sets player to either a SmartComputer, BelowAverageComputer, or a Human.
        player2 = generatePlayer(2);     // User sets player to either a SmartComputer, BelowAverageComputer, or a Human.
        pile = new Pile();               // Random amount from 20 - 95
        winner = "";                     // Empty
        turnOutput = "";                 // Empty  
    }
    
    
    /**
     * This method initiates the game where we the user generates the type of players involved, their individual names,
     * and who starts first among the two. We output the information of each turn and once the game is decided we 
     * display the information on the winner and ask the user if they would like to play again.
     */
    public void play()
    {
        // Player turn selection dialog
        System.out.println("\n1"
                + "Who do you want starting first? ");
        System.out.println("(1) Player 1 \n" + "(2) Player 2");
        System.out.print("Enter here: \n");
        
        
        // Section 1: Get and verify valid input
        int startingPlayer = scnr.nextInt();
        if((!(startingPlayer == 1))&&(!(startingPlayer == 2))) // If user input is invalid then,
        {
            System.out.println(" Input was invalid please enter either 1 or 2 ");  // Display error message
        }
            
        //while((!(startingPlayer == 1)) && (!(startingPlayer == 2))); // Continue till user input is either 1 or 2.
        
        
        
        // Section 2: Starts game where and infinite loop runs till a winner is declared and output the 
        // results for each turn till the winner is found.
        int i = 1;  // value for infinite loop
        int turn = 1; // Turn number
        System.out.println("Their are " + pile.getSize() + " marbles in the pile");
        
        if(startingPlayer == 1) // If player 1 is first
        {
            while(i < 2) // Infinite 
            {
                 
                // Player 1's turn
                player1.move(pile);   // Make a move
                boolean gameOver = checkForWinner(pile);   // Boolean to hold results if game is over initalized to the checkForWinner() method.
                
                if(gameOver)  // If gameOver is true then,
                {
                    System.out.println(endGame(player2)); // end the game
                    break;
                }
                else  // If game is not over then, 
                {
                    System.out.println(turnOutput(pile, player1, turn));   // Output turn info
                    turn++;   // Incrament turn  by 1
                }
                System.out.println("\n\n ===============================================\n\n");
                    
                
                // Player 2's turn
                player2.move(pile);   // Make a move
                gameOver = checkForWinner(pile);   // Boolean to hold results if game is over initalized to the checkForWinner() method.
                
                if(gameOver)  // If gameOver is true then,
                {
                    System.out.println(endGame(player1)); // end the game
                    break;
                }
                else  // If game is not over then,
                {
                    System.out.println(turnOutput(pile, player2, turn));  // Output turn info
                    turn++; // Incrament turn by 1
                }
                System.out.println("\n\n ===============================================\n\n");
                
            }
        }
        else    // If player 2 is first
        {
            while(i < 2) // Infinite
            {    
                
                // Player 2's turn
                player2.move(pile);   // Make a move
                boolean gameOver = checkForWinner(pile);   // Boolean to hold results if game is over initalized to the checkForWinner() method.
                
                if(gameOver)  // If gameOver is true then,
                {
                    System.out.println(endGame(player1)); // end the game
                    break;
                }
                else  // If game is not over then,
                {
                    System.out.println(turnOutput(pile, player2, turn));  // Output turn info
                    turn++; // Incrament turn by 1
                }
                System.out.println("\n\n ===============================================\n\n");
                
                
                // Player 1's turn
                player1.move(pile);   // Make a move
                gameOver = checkForWinner(pile);   // Boolean to hold results if game is over initalized to the checkForWinner() method.
                
                if(gameOver)  // If gameOver is true then,
                {
                    System.out.println(endGame(player2)); // end the game
                    break;
                }
                else  // If game is not over then, 
                {
                    System.out.println(turnOutput(pile, player1, turn));   // Output turn info
                    turn++;   // Incrament turn  by 1
                }
                System.out.println("\n\n ===============================================\n\n");    
                
            }
        }     
    }
    
    
    /**
     * This method generates a Player by first asking the user what type of player is the Player() object. Then 
     * based on the user's input we initialize the Player() object to either a BelowAverageComputer, SmartComputer, or
     * Human and return player.
     * @param playerNum
     * @return player
     */
    public Player generatePlayer(int playerNum)
    {
        // Section 1: Ask user what type of player is this Player() Object until the player enters a valid input.
        System.out.println("\nHello Player " + playerNum + " what type of player are you?");
        System.out.println(" (1) A Below Average Inteligence Computer \n" + " (2) A Smart Computer \n" + " (3) A Human");
        System.out.print("Enter here: \n");
        int playerType = scnr.nextInt(); // User input
        
           
        if( playerType > 3 && playerType < 1) // If input invalid then, print out error message
        {
            while(playerType > 4 && playerType < 0)
            {
                System.out.println("Sorry that value isn't accepted. I'll ask again what type of player are you?");
                System.out.println(" *(1) A Below Average Inteligence Computer \n" + " *(2) A Smart Computer \n" + " *(3) A Human\n");
                playerType = scnr.nextInt();
            }
        }   
        
        
        
        
        // Section 2: Initalize player to the userInput given through a switch case
        String givenName = generateName();  // String holding players name and initalize to the method generateName() to ask user to input name
        Player player = new Human(givenName); // Temp initialization not final output.
        
        switch ( playerType ) // Based on valid User input if
        {   
            case 1: // User input is 1 then,
                BelowAverageComputer average = new BelowAverageComputer(givenName); // Player type is BelowAverageComputer
                player = average; // Set player type
                break;
            case 2: // User input is 2 then, 
                SmartComputer smart = new SmartComputer(givenName); // Player type is a SmartComputer
                player = smart; // Set player type
                break;
            case 3: // User input is 3 then,
                Human human = new Human(givenName); // Player type is a Human
                player = human; // Set player type
        }
            
        // Section 3: Return the desired Player type the user desired
        return player;
    }
    
    
    /**
     * This method ask the user for as Specific players name and returns the givenName
     * @return givenName
     */
    public String generateName()
    {
       System.out.println("\nGreat What is your name? "); // Ask user for name
       String givenName = scnr.next(); // input User info 
       return givenName; // Return the given name
    }
    
    
    
    /**
     * This method returns an output of what occurred in the turn as a multi-line String, by passing through
     * the Pile, Player, and turn number.
     * @param pile
     * @param player
     * @param turn
     * @return answer
     */
    public String turnOutput(Pile pile, Player player, int turn)
    {
        String str = "";      
        str+= "****************** Turn" + turn + "******************\n";
        str += player.getName() + " has taken " + pile.getMarblesTaken() + " marbles from the pile. \n";
        str += "The pile now has " + pile.getSize() + " marbles remaining. \n *******************************************" ;
        return str;
    }
    
    
    /**
     * This method checks if the game is over by passing the Pile through the parameter and 
     * checking if the pile size is 0. If so then the game is over.
     * @param pile
     * @return answer
     */
    public boolean checkForWinner(Pile pile)
    {
        boolean answer = false; // boolean variable holding the answer
        
        if(pile.getSize() == 0) // If pile has no more marbles then,
        {
            answer = true;  // the game is over
        }
        else // If pile size is greater then 0.
        {
            answer = false; // the game is not over.
        }      
        return answer; // Return ansewr
    }

    
    /**
     * This method returns a string stating that the player pass through the parameter has
     * won the game and calls the player by it's name.
     * @param player
     * @return winningOutput 
     */
    public String endGame(Player player)
    {   
        String winningOutput = "";
        winningOutput += "*****************************************************\n";
        winningOutput += "\tCongratulations " + player.getName() + " you won the game!\n";   
        winningOutput += "*****************************************************\n";
        return winningOutput;
    }

}
