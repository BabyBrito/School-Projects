/*
	example of command line parsing via getopt
	usage: getopt [-dmp] -f fname [-s sname] name [name ...]

	Paul Krzyzanowski
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>

int
main(int argc, char **argv)
{
	extern char *optarg;
	extern int optind;
	int c, err = 0; 
	int aflag=0, bflag=0, cflag = 0, dflag=0;
	char *cname,  *num;
	static char usage[] = "usage: %s [-ab] -c cname -d num name [name ...]\n";
	int count = 0;

	while ((c = getopt(argc, argv, "abc:d:")) != -1)
		switch (c) {
		case 'a':
			aflag = 1;
			count++;
			break;
		case 'b':
			bflag = 1;
			count++;
			break;
		case 'c':
			cflag = 1;
			cname = optarg;
			count++;
			count++;
			break;
		case 'd':
			dflag = 1;
         		num = optarg;
			count++;
			count++;
			break;
		case '?':
			err = 1;
			break;
		}

	if (cflag == 0 || dflag == 0) {	/* -f was mandatory */
		if(cflag == 0 && dflag == 1){
			fprintf(stderr, "%s: missing -c option\n", argv[0]);
			fprintf(stderr, usage, argv[0]);
			exit(1);
		} else if(dflag == 0 && cflag == 1){
			fprintf(stderr, "%s: missing -d option\n", argv[0]);
			fprintf(stderr, usage, argv[0]);
			exit(1);
		} else {
			fprintf(stderr, "%s: missing -c and -d  option\n", argv[0]);
			fprintf(stderr, usage, argv[0]);
			exit(1);
		}
	} else if (isdigit(num[0]) == 0 ) {
		printf("-d only takes an ineger.\n");
		exit(1);
	} else if ((optind+2) > argc) {
		/* need at least one argument (change +1 to +2 for two, etc. as needeed) */
		printf("optind = %d, argc=%d\n", optind, argc);
		fprintf(stderr, "%s: missing name\n", argv[0]);
		fprintf(stderr, usage, argv[0]);
		exit(1);
	} else if (argc - (count + 1) > 3) {
		printf("Too many arguments\n");
		exit(1);
	} else if (err) {
		fprintf(stderr, usage, argv[0]);
		exit(1);
	}


	/* see what we have */

	printf("Options: ");
	if(aflag == 1)
		printf("-a, ");
	if(bflag == 1)
		printf("-b, ");
	if(cflag == 1)
		printf("-c, ");
	if(dflag == 1)
		printf("-d \n");

	printf("Arguments: ");
	printf("%s ", cname);
	printf("%s\n", num);

	printf("Perameters: ");
	if (optind < argc)	/* these are the arguments after the command-line options */
		for (; optind < argc; optind++)
			printf("%s ", argv[optind]);
	printf("\n");
	exit(0);
}
