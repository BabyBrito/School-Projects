package assignment6;

/**
 * A class to create, add, and multiply polynomials. A polynomial is defined
 * as a sum of terms where each term has variable x, an int coefficient, and
 * a nonnegative int exponent
 */

public class Polynomial
{
    
   
   private Node head ;   // points to the first Node of a Polynomial
   
   
   /**
    * Default constructor creates a Polynomial with no terms
    */
    public Polynomial()  
    {
        head = null;    
    }
   
    
   /**
    * "Copy" constructor. Creates a "deep copy" of a given Polynomial. 
    * I.e. a new Polynomial with identical terms
    * @param p the Polynomial to be copied
    */
    public Polynomial(Polynomial p) 
    {  

    }
  
    /**
     * Creates a new Term and Node containing it and inserts it in its proper
     * place in this Polynomial (i.e. in ascending order by exponent) 
     * @param coeff the coefficient of the new Term
     * @param expo the exponent of the new Term
     */
    public void addTerm(int coeff, int expo)
    {
        Term term = new Term(coeff, expo);  // New Term
        Node temp = new Node(term);  // New Node
       
        Node tail = head; // place holder for last 

        
        if(head == null)  // If list is empty
        {
            tail = head;    // the tail is the head
        }
        else  // if not
        {
            while(tail.info != null)  // While not at the last node
            {
                if(tail.next == null)
                {
                    break;
                }
                else
                {
                    tail = tail.next;  // set tail to the next node until the tail is  found;
                }
                
            }
        }
   
        if (head == null)       // if list empty
        {
            head = temp;   // set the temp as head.
        } 
        else if(temp.info.getExponent() >= tail.info.getExponent())  // If list not empty and the exponenet for the tail is less then temp's exponent
        {
            tail.next = temp; // set temp as last node.
        }
        else
        {
            Node current = head;  // second temp node to traverse list
            Node nodePrior = head;  // node to place node prior to temp 2
            
            while(current != tail)   // While not at the end of the list
            {
                
                if(temp.info.getExponent() <= current.info.getExponent()) // temp has a greater exponent then temp2
                {
                    if(current != head)  // if current is not head 
                    {
                        nodePrior.next = temp;  // node prior next node is temp
                        temp.next = current;   // and current will be the node after temp
                    }
                    else  // if current is the head
                    {
                        temp.next = head;  // temp is the new head and head is after temp
                        break;
                    }
                }
                else  // if exponent is not greater
                {
                    nodePrior = current;  // set nodePrior to current
                    current = current.next; // and advance current
                }
            }
        }
    
    }      
  
    
   /**
    * Returns a polynomial as a String in this form: x + 3x^2 + 7x^3 + x^5
    * @return the polynomial as a String
    */
    public String toString()
    {
       if(head == null)
       {
           return "Null";
       }
   
       String str = "";
       collectTerms();
       Node temp = head; 		
       
       
       while (temp != null)            
       {
            str += temp.info + " ";
            temp = temp.next; // temp = next term 
       }
       
       return str + "\n";
    }
    
   
   // collect terms of a Polynomial object. I.e. replace all terms having the 
   // same exponent with a single term which is their sum
    private void collectTerms()         
    {
        Node temp = head; // Get first node
        
        while( temp.next != null ) //while not the only node
        {
            Term current = temp.info;        // Current term
            Term termAfter = temp.next.info;  // Next term
            
            while (current.getExponent() == termAfter.getExponent()) // While current exponent is equal to exponent after
            {
                int coefficient = current.getCoefficient() + termAfter.getCoefficient();
                Term term = new Term(coefficient, current.getExponent());
                
                temp.info = term; //'this' get new resulting term
                temp.next = temp.next.next; //point to the term after next
                
                current = temp.info; //new term
                termAfter = temp.next.info; //new next term
            }
            
            if ( temp.next == null ) // If last node then,
            {
                break; // Break.
            }  
            temp = temp.next; // temp is now next term
        }
    }
   
   
   /**
    * Multiply this Polynomial by another Polynomial
    * @param p the other Polynomial
    * @return the product of the two Polynomials
    */
    public Polynomial polyMultiply(Polynomial p)      
    {  
        Polynomial results = new Polynomial();
        Node temp1 = head; //head of first list
        Node temp2 = p.head; //head of second list

        
        while (temp1 != null) // While list 1 is not null
        {
            while (temp2 != null) // And while list 2 isnt null
            {
                int exponent = temp2.info.getExponent() + temp1.info.getExponent(); // add exponents
                int coefficient = temp2.info.getCoefficient() * temp1.info.getCoefficient(); // multiply coefficients
                results.addTerm(coefficient, exponent); // add to new polynomial
                temp2 = temp2.next; //next node
            }
            temp2 = p.head; 
            temp1 = temp1.next; 
        }
        return results ; //resulting polynomial
      
    }
   
   
   /**
    * Add this Polynomial and another Polynomial
    * @param p the other Polynomial
    * @return the sum of the two Polynomials
    */
    public Polynomial polyAdd(Polynomial p)       
    {       
        Polynomial results = new Polynomial(p);
        Node temp = head; //first polynomial  
          
        while(temp != null) // while temp is not null
        {
            results.addTerm( temp.info.getCoefficient(), temp.info.getExponent()); //add the terms from polynomial passeed to results
            temp = temp.next; //next node
        }
        return results;      
    }
   
   
    // Node class definition - DO NOT MODIFY!
    class Node <E extends Term>
    {
      private E info ;     // each node stores an object of the 
                           // type-parameter class...
      private Node next ;  // ...and a pointer to another node

      // Node Constructor 
      // parameter x is an object of the type-parameter class
      Node(E x)         
      {
         info = x;	// set info portion to parameter passed
         next = null;	// not pointing to another Node yet
      }
      
    } 
   
} 