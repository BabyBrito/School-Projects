package assignment6;

/**
 * Class to create an algebraic term such as 2x^3 where 2 is the coefficient and 3 is the exponent.
 * This values are passed in the parameter of the constructor and the class contains getters for 
 * the coefficient and exponent. The class also contains a method to return a String representation 
 * of the term with different cases.
 * @author Brito
 */
public class Term 
{
    
    private int coefficient;  // interger value for the coeeficient
    private int exponent;   // integer value for the exponent (must be non-negative)
    
    
    /**
     * Constructor for the class where the coefficient and exponent are passed in the parameter
     * @param coefficient
     * @param exponent 
     */
    public Term(int coefficient, int exponent)
    {
        this.coefficient = coefficient;
        this.exponent = exponent;
    }
    
    
    /**
     * This method returns the value of the coefficient.
     * @return coefficient
     */
    public int getCoefficient()
    {
        return coefficient;
    }
    
    
    /**
     * This method returns the value of the exponent.
     * @return exponent
     */
    public int getExponent()
    {
        return exponent;
    }
    
    
    /**
     * This method returns a String representation of the term depending on the values of the
     * coefficient and exponent.
     * @return 
     */
    public String toString()
    {
        String str = "";
        if(coefficient == 1 && exponent == 1) // If cooeficient and exponent are both 1 then,
        {
            str = "x";  // return x.
        }
        else if(coefficient == 1 && (!(exponent == 1))) // If cooeficient is 1 and exponent is not 1 then,
        {
            str = "x^" + exponent;  // return x and the exponent.
        }
        else if(exponent == 1 && (!(coefficient == 1))) // If exponent is 1 and coefficient is not 1 then,
        {
            str = coefficient + "x";  // return coefficient and x.
        }
        else if(exponent == 0)  // If exponent is 0 then,
        {
            str = String.valueOf(coefficient);  // return the coefficient only
        }
        else  // If non of these cases apply then,
        {
            str = coefficient + "x^" + exponent;  // return the coefficient, x, and the exponent.
        }
        return str;
    }
   
}
