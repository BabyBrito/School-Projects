package assignment.pkg5;
import java.lang.Math;


/**
 * This class represents a sphere that extends the Shape3D class. This class inherits the constructor of the superclass and the sphere 
 * also contains an additional instance variable for the radius. This class has methods to compute and return both the volume and the
 * surface area of the sphere, a method to return a string representation of the name, and a method to return a string representation 
 * of all the data values for the sphere.
 * @author Brito
 */
public class Sphere extends Shape3D
{
    
    private double radius;  // Instace variable to represent the radius as a double
    
    
    /**
     * Constructor of the sphere where we pass through x, y, and z coordinates of the center point and pass to 
     * the super constructor, and pass through a double for the radius.
     * @param x
     * @param y
     * @param z
     * @param radius 
     */
    public Sphere(int x, int y, int z, double radius)
    {
        super(x,y,z);
        this.radius = radius;         
    }
    
    
    /**
     * This method compute and returns the surface area of the sphere that overrides the method in the superclass.
     * @return surfaceArea
     */
    @Override
    public double getSurfaceArea()
    {
        double surfaceArea = 4 * Math.PI * Math.pow(radius, 2);
        return surfaceArea;
    }
    
    /**
     * This method compute and returns the volume of the sphere that overrides the method in the superclass.
     * @return volume
     */
    @Override
    public double getVolume()
    {
       double volume = (4.0/3.0) * Math.PI * Math.pow(radius, 3);
       return volume;
    }
    
    
    /**
     * This method returns a string representation of all the data values of the sphere.
     * @return str
     */
    @Override
    public String toString()
    {
        String str = "Sphere: " + super.toString() + ", Radius = " + radius;
        return str;
    }
    
    
    /**
     * This method returns a string representation of the name of the class.
     * @return "Sphere"
     */
    @Override
    public String getName()
    {
        return "Sphere";
    }
    
    
  
}
