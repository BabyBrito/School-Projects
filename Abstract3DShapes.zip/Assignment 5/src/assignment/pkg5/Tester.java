
package assignment.pkg5;
import java.util.Arrays;
import java.util.Comparator;


/**
 * Tester Class for the package where we create one of each of the Shape3D() objects and store it in an array called shapes. We then print out all the data values
 * for each of the shapes and it's surface area. After we sort the array via the  Arrays.sort method via the compareTo method in the Shape3D superclass where we 
 * sort in ascending order per the volume of the object. We then print out all the new list and it's volume. After we use the created static class called 
 * ShapesComparator where we sort the objects in descending order per the distance of the center point to the origin and print out the new list afterwards.
 * @author Christian Brito
 */
public class Tester
{
    
    
    /**
     * Main Method
     * @param args 
     */
    public static void main(String args[])
    {
        
        // Initialization for each shape where we hardcode each data value.
        Sphere sphere = new Sphere(8,5,2,14); 
        Cone cone = new Cone(-1,4,-5, 11, 15);
        Cylinder cylinder = new Cylinder(6,-7,-35,14,12);
        Parallelepiped parallelepiped = new Parallelepiped(9,16,7,19,9,13);  
        
        
        // Array to store each shape
        Shape3D[] shapes = {sphere, cone, cylinder, parallelepiped};
        
        
        // List containg the name of the shape, it's data values, and the surface area.
        System.out.println("List of shapes and it's given data values and their surface areas\n");
        for(Shape3D shape : shapes)
        {
           System.out.println(shape.toString() + ", SURFACE AREA = " + shape.getSurfaceArea() + "\n");     
        }
        System.out.println("\n");
        
        
        // Sort Array in asscending order per it's volume.
        Arrays.sort(shapes);
        
        
        // List containg the name of the shape ordered in ascending order per its volume.
        System.out.println("List after sorting it in ascending order per it's volume\n");
        for(Shape3D shape : shapes)
        {
           System.out.println(shape.getName() + " has a volume of " + shape.getVolume() + "\n");     
        }
        System.out.println("\n");
        
        
        //  ShapesComparator() object to pass thorugh the sort method to print the list in descending order.
        ShapesComparator comp = new ShapesComparator();
        
        
        // Sort the array again in descending order per it's distnace of the center point to the origin.
        Arrays.sort(shapes, comp);
        
        
        // List after sorting in descending order.
        System.out.println("List after soring in descending order per the distance of it's center point from the origin\n");
        for(Shape3D shape : shapes)
        {
           System.out.println("The " + shape.getName() + "'s center point distance from the origin is " + shape.getDistanceFromCenter() + "\n");     
        }
        
    }
    
    
    /**
     * This class implements Java's Comparator interface where we generate a method called compare, pass through two objects to compare
     * and tell the computer to sort the objects in descending order per the distance of it's center point from the origin.
     */
    public static class ShapesComparator implements Comparator
    {

        @Override
        public int compare(Object object1, Object object2)
        {
            Shape3D shape1 = (Shape3D)object1;  //Downcast the first object to a shape3D()
            double distance1 = shape1.getDistanceFromCenter();  // Dustance of the center point of shape1.
            Shape3D shape2 = (Shape3D)object2;  //Downcast the second object to a shape3D()
            double distance2 = shape2.getDistanceFromCenter();  // Dustance of the center point of shape2.
            
            if(distance1 < distance2) // If distnace1 is less then distance2
            {
                return 1;  // return 1 to go after 
            }
            else if (distance1 > distance2) // If distance1 is greater then distance2 
            {
                return -1; // return -1 to go before
            }
            else
            {
               return 0;  // retrun 0 if objects are equal
            }
            
        }
        
    }
    
}
