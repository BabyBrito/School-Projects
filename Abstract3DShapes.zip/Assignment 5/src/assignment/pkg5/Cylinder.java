package assignment.pkg5;
import java.lang.Math;


/**
 * This class represents a Cylinder that extends the Shape3D class. This class inherits the constructor of the superclass and the cylinder 
 * also contains additional instance variables for the radius and the height. This class has methods to compute and return both the volume and the
 * surface area of the cylinder, a method to return a string representation of the name, and a method to return a string representation 
 * of all the data values for the cylinder.
 * @author Brito
 */
public class Cylinder extends Shape3D
{
    
    private double radius;  // double to represent the value of the radius
    private double height;  // double to represent the value if the height
    
    
    /**
     * Constructor for the Cylinder where we pass through x, y, and z coordinates of the center point and pass it to 
     * the super constructor, and pass through a double for the radius and the height.
     */
    public Cylinder(int x, int y, int z, double radius, double height)
    {
        super(x,y,z);
        this.radius = radius;
        this.height = height;
    }
    
    
    /**
     * This method compute and returns the surface area of the Cylinder that overrides the method in the superclass.
     * @return surfaceArea
     */
    @Override
    public double getSurfaceArea()
    {
        double surfaceArea = ( 2 * Math.PI * Math.pow(radius, 2)) + ( 2 * Math.PI * radius * height) ;
        return surfaceArea; 
    }
    
    
    /**
     * This method compute and returns the volume of the Cylinder that overrides the method in the superclass.
     * @return volume
     */
    @Override
    public double getVolume()
    {
        double volume = Math.PI * Math.pow(radius, 2) * height;
        return volume;
    }
    
    
    /**
     * This method returns a string representation of all the data values of the Cylinder.
     * @return str
     */
    @Override
    public String toString()
    {
        String str = "Cylinder: " + super.toString() + ", Height = " + height + ", Radius = " + radius;
        return str;
    }
    
    
    /**
     * This method returns a string representation of the name of the class.
     * @return "Cylinder"
     */
    @Override
    public String getName()
    {
        return "Cylinder";
    }

}
