
package assignment.pkg5;

/**
 * This Class creates a Point3D() that represents a point inside of a 3D Shape().
 * @author Christian Brito
 */
public class Point3D
{
    
    
    private int x;   // x coordinates 
    private int y;   // y coordinates 
    private int z;   // z coordinates 
    
    /**
     * Constructor for the Point3D() where we initialize the integer values for the x, y, and z  through
     * the integer values passed through the parameter of the constructor. 
     * @param x
     * @param y
     * @param z 
     */
    public Point3D(int x, int y, int z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    /**
     * Returns the integer value of the x coordinate.
     * @return x
     */
    public int getX()
    {
        return x;
    }
    
    /**
     * Returns the integer value of the y coordinate.
     * @return y
     */
    public int getY()
    {
        return y;
    }
    
    /**
     * Returns the integer value of the z coordinate.
     * @return z
     */
    public int getZ()
    {
        return z;
    } 
    
    /**
     * Returns a string representation of the Point3D() x, y, and z coordinates.
     * @return ( "X: " + x + ", Y: " + y + ", Z: " + z )
     */
    public String toString()
    {
       return "X = " + x + ", Y = " + y + ", Z = " + z ;
    }
   
}
