package assignment.pkg5;


/**
 * This class represents a Parallelepiped AKA a Right Rectangular Prism that extends the Shape3D class. This class inherits the constructor of the superclass and the Parallelepiped
 * also contains additional instance variables for the length, width and height. This class has methods to compute and return both the volume and the
 * surface area of the Parallelepiped, a method to return a string representation of the name, and a method to return a string representation 
 * of all the data values for the Parallelepiped.
 * @author Brito
 */
public class Parallelepiped extends Shape3D
{
    
    private double length;  //double to represent the value for the lenght
    private double width;   //double to represent the value for the width
    private double height;  //double to represent the value for the height
    
    
    /**
    * Constructor for the Parallelepiped where we pass through x, y, and z coordinates of the center point and pass it to 
    * the super constructor, and pass through a double for the length, width, and height.
    */
    public Parallelepiped(int x, int y, int z, double length, double width, double height)
    {
        super(x,y,z);
        this.length = length;
        this.width = width;
        this.height = height;
    }
    
    
    /**
    * This method compute and returns the surface area of the Parallelepiped that overrides the method in the superclass.
    * @return surfaceArea
    */
    public double getSurfaceArea()
    {
        double surfaceArea =  2 * ((length * width) + (length * height) + (width * height)) ;
        return surfaceArea;
    }
    
    /**
    * This method compute and returns the surface area of the Parallelepiped that overrides the method in the superclass.
    * @return surfaceArea
    */
    public double getVolume()
    {
       double volume = length * width * height;
       return volume;
    }
    
      
    /**
     * This method returns a string representation of all the data values of the Parallelepiped.
     * @return str
     */
    public String toString()
    {
        String str = "Parallelepiped: " + super.toString() + ", Length = " + length + ", Width = " + width + ", Height = " + height;
        return str;
    }
    
    
    /**
     * This method returns a string representation of the name of the class.
     * @return "Parallelepiped"
     */
    @Override
    public String getName()
    {
        return "Parallelepiped";
    }
    
}
