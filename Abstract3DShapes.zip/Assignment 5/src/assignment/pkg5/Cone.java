package assignment.pkg5;
import java.lang.Math;


/**
 * This class represents a Cone that extends the Shape3D class. This class inherits the constructor of the superclass and the cone
 * also contains additional instance variables for the radius and the height. This class has methods to compute and return both the volume and the
 * surface area of the cone, a method to return a string representation of the name, and a method to return a string representation 
 * of all the data values for the cone.
 * @author Brito
 */
public class Cone extends Shape3D
{
    
    
    private double radius;  // double to represent the value of the radius
    private double height;  // double to represent the value if the height
    
 
    /**
    * Constructor for the Cone where we pass through x, y, and z coordinates of the center point and pass it to 
    * the super constructor, and pass through a double for the radius and the height.
    */
    public Cone(int x, int y, int z, double radius, double height)
    {
        super(x,y,z);
        this.radius = radius;
        this.height = height;   
    }
    
    
    /**
     * This method compute and returns the surface area of the Cone that overrides the method in the superclass.
     * @return surfaceArea
     */
    @Override
    public double getSurfaceArea()
    {
        double slant = Math.sqrt( (Math.pow(radius, 2)) + (Math.pow(height, 2)) );
        double surfaceArea = Math.PI * radius * (radius + slant);
        return surfaceArea;
    }
    
    
    /**
     * This method compute and returns the surface area of the Cone that overrides the method in the superclass.
     * @return surfaceArea
     */
    @Override
    public double getVolume()
    {
        double volume = (Math.PI * Math.pow(radius, 2) * height) / 3;
        return volume;
    }
    
    
    /**
     * This method returns a string representation of all the data values of the cone.
     * @return str
     */
    @Override
    public String toString()
    {
        String str = "Cone: " + super.toString() + ", Height = " + height + ", Radius = " + radius;
        return str;    
    }
    
    
    /**
     * This method returns a string representation of the name of the class.
     * @return "Cone"
     */
    @Override
    public String getName()
    {
        return "Cone";
    }
    
    
}
