package assignment.pkg5;
import java.lang.Math;


/**
 * This class is an abstract superclass that represents a 3D shape where we pass through the constructor the x, y, and z coordinates of a Point3D() object
 * to represent the center point of the object. This class contains 3 concrete methods, one to give us the distance of the center point from the origin point at (0,0,0),
 * the second to return a string representation of the center coordinates that's overridden by the subclasses, and the last to return the name of the shape that will also
 * be overridden by the subclasses. The last two methods are two abstract classes to compute and return the surface area and the volume of the 3D shape that will be
 * overridden by the subclass.
 * @author Brito
 */
public abstract class Shape3D implements Comparable
{  
    
    private Point3D center;  // Center point of the shape.
      
    
    /**
     * Constructor of the Shape3D() object where we pass through the parameter the x, y, and z coordinates of the center point.
     * @param x
     * @param y
     * @param z 
     */
    public Shape3D(int x, int y, int z)
    {
        center = new Point3D(x,y,z);
    }
    
    /**
     * This method is concrete and returns the distance of the center point from the point of origin by getting the hypotenuse of the right triangle
     * by using the hypotenuse theorem a^2 + b^2 = c^2 where the distance will be sqrt(c^2) and the adjacent side has length z and the opposite side has 
     * length sqrt(a^2 + b^2).
     * @return hypotenuse
     */
    public double getDistanceFromCenter()   // Probably Needs work on the inheritance.
    {  
        double adjacent = center.getZ();
        double opposite = Math.sqrt( ( (Math.pow(center.getX(), 2)) + (Math.pow(center.getY(), 2)) ) );
        double hypotenuse = Math.sqrt( ( (Math.pow(adjacent, 2))+(Math.pow(opposite, 2)) ) ); 
        return hypotenuse;
    }

    
    /**
     * Abstract method to return the surface area of the 3D shape.
     */
    public abstract double getSurfaceArea();
    
    
    /**
     * Abstract method to return the volume of a 3D shape.
     * @return 
     */
    public abstract double getVolume();
    
    
    /**
     * Concrete method to return a string representation of the coordinates of the center point.
     * @return str
     */
    public String toString()
    {
        String str = "Coordinates of center: " + center.toString();       
        return str;
    }
    
    
    /**
     * Concrete method from to utilize Java's comparable interface where we return a number to represent if the object passed
     * in the parameter goes before or after the object being compared with.
     * @param otherShape
     * @return -1, 1, or 0
     */
    public int compareTo(Object otherShape)
    {
        // Downcast Object for comparison
        Shape3D other = (Shape3D)otherShape;
             
        if(this.getVolume() < other.getVolume()) // if this object's volume is less then other
        {
            return-1;  // it comes before other
        }
        else if(this.getVolume() > other.getVolume()) // else if this volume is greater then 1
        {
            return 1;  // it comes after other
        }
        else // if objescts have equal volume
        {
            return 0;  // return 0
        }        
    }
    
    
    /**
     * Method to return string representation of the Shape3D() object that's overridden by the subclass.
     * @return null
     */
    public String getName()
    {
        return null;
       
    }
    
}
